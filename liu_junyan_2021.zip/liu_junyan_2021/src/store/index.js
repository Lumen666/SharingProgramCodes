import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
 //在state中定义整个项目范围的的全局变量
    //在需要调用本地存储对象的时候，使用getItem方法来获取对应的值
    //如果退出登录时没有将localStorage里的key的值改为空，则可以在这里判断值是否为true的字符串，是的话就把值改为布尔值的true,不是就改为布尔值的falsechinese
    isLogin:localStorage.getItem("login") == "true" ? true : false
  },
  mutations: {
    //定义需要修改某个state状态（变量）的方法
    changeLogin(state){
     console.log(state)
     state.isLogin = !state.isLogin
    }
  },
  actions: {
  },
  modules: {
  }
})

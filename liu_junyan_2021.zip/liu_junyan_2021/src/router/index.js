//建立路由的第一步，在views文件夹内创建新的vue页面文件


import Vue from 'vue'
import VueRouter from 'vue-router'
import firstPage from '../views/first.vue'
import cartPage from '../views/cart.vue'
import minePage from '../views/mine.vue'
import detailPage from '../components/productDetail.vue'
import testPage from '../views/test.vue'
import login from '../views/login.vue'
import store from '../store/index'
import { Store } from 'vuex'

//建立路由的第二步，在这里import新建的vue页面文件，自定义一个连接词


Vue.use(VueRouter)

const routes = [
  {
    path: '/first',
    //默认给路由取的名字，可以不写，但建议写上
    name: 'Home',
    component: firstPage
  },
  {
    path: '/Category',
    name: 'Category',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.

    //问题：这个是直接引用文件？？？？？
    component: () => import(/* webpackChunkName: "about" */ '../views/Category.vue')
  },
  {//建立路由的第三步，在这个routes数组内加上一个对象，填写path(路由名)和component(组件名)
    path: '/cart',
    name: 'cart',
    component: cartPage
  },
  {
    path: '/mine',
    name: 'mine',
    component: minePage
  },
  {
    //:abc是我们自定义的动态路由名，加了之后这个path会被前端放入parameter属性里，后台可以打开parameter包找到需要的数据
    // path: '/productDetail/:abc'+'.html',
    path: '/productDetail/:pid' + '.html',
    name: "xianqiang",
    component: detailPage
  },
  {
    path: '/test',
    name: 'test',
    component: testPage
  },
  {
    path: '/login',
    name: 'login',
    component: login
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

// beforeEach =>前置的导航守卫
//from：从哪个页面 .
//to:去哪个页面
//next:执行跳转
router.beforeEach((to, from, next) => {
  //要跳转到哪个页面
  console.log(to)
  //从哪个页面跳转过来的
  console.log(from)
  //console.log(next)
  console.log(Store)

  //如果是跳转到登录页面，则直接下一步
  // if (to.name == 'login') {
  //   next();
  // } else {
  //   //否则的话，我们先判断用户是否登录
  //   //如果没有登录则跳转到登录页面
  //   if (store.state.isLogin == false) {
  //     next("/login")
  //   } else {
  //     next();
  //   }
  // }


  if(store.state.isLogin){
    //如果为登录状态，直接跳转不需要任何的处理
    next();
  }else{
    //如果没有登录,且要去的是login页面，那就去吧
    if(to.path == "/login"){
      next();
      //如果没有登录，且去的是非login页面，那就去login页面吧
    }else{
      next("/login")
    }
  }







})

export default router



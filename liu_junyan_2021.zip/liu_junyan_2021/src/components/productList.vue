<template>
<!--下面的@click="jumpPage(item.id)"里的id是对应数据库里的id，是不能改的，是个实参  -->
  <div id="product-list" class="over">
 
    <div
      class="products left"
      v-for="(item, index) in list"
      :key="index"
      @click="jumpPage(item.id)"
    >
      <img :src="item.src" alt="" />
      <div class="food">{{ item.title }}</div>
      <div class="price left">￥{{ item.price }}<span class="discount">满减</span></div>
      <div class="btn right">看相似</div>
    </div>
  </div>
</template>

<style lang="less">
#product-list {
  //&表示与外面一层的#product-list是同一级
  &.over {
    overflow: hidden;
    zoom: 1;
  }

  font-family: "微软雅黑";
  font-size: 20px;

  .products {
    width: 50%;
    padding: 10px;
    box-sizing: border-box;
    // border: 1px solid red;
    background: #ffff;

    .food {
      text-align: left;
      font-size: 13px;

      //以下几句是多行文本的隐藏方法，重要！！
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      //  破坏单词完整性，注意区分多个单词的连接时使用。这也就是-中划线和_下划线的区别
      word-break: break-all;
    }

    img {
      width: 100%;
    }
    .price {
      color: red;
      font-size: 16px;
      height: 16px;
        // border: 1px solid green;
        vertical-align: sub;


      .discount {
        border: 1px solid red;
        border-radius: 5px;
        font-size: 12px;
        padding: 0 2px;
        margin-left: 3px;
      }
    }
    .btn {
      background: #f0f2f5;
      color: #808080;
      padding: 5px 10px;
      border-radius: 20px;
      font-size: 12px;
    }
  }
}

.left {
  float: left;
}

.right {
  float: right;
}
</style>

<script>
//  1.我们准备要用接口替代list里写死的数据，首先引入axios模块。
import axios from "axios"



export default {





  data() {
    return {
      list: [
        {
          src: require("@/assets/products/p1.jpg"),
          title:
            "日本久野（TEOEO）智能马桶一体式坐便器全自动翻盖清洗加热烘干无水箱座便器 【旗舰版】",
          price: 3099.0,
          id: "1001",
        },
        {
          src: require("@/assets/products/iphone13.jpg"),
          title:
            "Apple iPhone 13 Pro Max (A2644) 256GB 银色 支持移动联通电信5G 双卡双待手机",
          price: 9799.00,
          id: "1002",
        },
                {
          src: require("@/assets/products/2.png"),
          title:
            "德米克（DEMY）骨传导耳机蓝牙耳机跑步无线运动耳机游泳防水骨传导蓝牙耳机  时尚钢琴黑 磁吸充电",
          price: 2388,
          id: "1003",
        },
                {
          src: require("@/assets/products/3.jpg"),
          title:
            "萱品车载时钟室内温度计万年历电子钟两用气温计湿度表 室温计加空气干湿温度计 车用钟表家用温湿度计 白色温湿度计款",
          price: 85,
          id: "1004",
        },
                {
          src: require("@/assets/products/4.jpg"),
          title:
            "牛皮女包2021新品韩版水桶包软皮女包简约单肩斜挎女士包包甜美手提包 香草黄小号",
          price: 158,
          id: "1005",
        },
                {
          src: require("@/assets/products/5.jpg"),
          title:
            "联想（Lenovo）小新Pro16 标压锐龙版 2021 全面屏轻薄笔记本电脑 R7-5800H 16G 512G GTX1650",
          price: 6746,
          id: "1006",
        },
                {
          src: require("@/assets/products/6.jpg"),
          title:
            "联想（Lenovo）YogaDuet 英特尔酷睿i5 13英寸  二合一平板笔记本电脑 新】i5-1135G7 16G 512G 2K触屏 人脸识别 标配背光蓝牙键盘",
          price:6999 ,
          id: "1007",
        },
                {
          src: require("@/assets/products/7.jpg"),
          title:
            "BlackKiss秋冬新款欧美时尚复古印花托特包女单肩大包手提包大容量女包 咖啡色",
          price: 188,
          id: "1008",
        },
                {
          src: require("@/assets/products/8.jpg"),
          title:
            "Beats Flex 蓝牙无线 入耳式手机耳机 颈挂式耳机 带麦可通话 Beats 经典黑红",
          price: 399,
          id: "1009",
        },
                {
          src: require("@/assets/products/9.jpg"),
          title:
            "晋鸿圣诞节礼物星宠暖手宝充电暖宝宝迷你可爱暖手宝充电宝二合一生日礼物女生老婆热水袋儿童学生暖手蛋神器 星宠迷你舱-暖手宝【6500MAH】+精美包装",
          price: 178,
          id: "1010",
        },

      ],
    };
  },
  methods: {
    //通过js代码的方式。实现页面跳转
    //jumpPage(pid)里的pid是个形参，只是代表着最上面@jumPage(item.id)里传过来的item.id数据，只是用来占个坑，所以pid这个名字可以随便取，不过需要注意的是下面这个jumpPage方法里的pid都和这个形参是同一个东西。
    jumpPage(pid) {
      //通过this.$router路由器对象，可以访问到当前vue项目中的路由器对象
      console.log(this.$router);
      console.log(pid);

      //push函数就是推送（跳转到指定的页面），需要在router文件夹的inde.js中注册要跳转的页面。
      // /productDetail只是指定了要跳转的页面，而跳过去之后要显示哪些数据呢？这就要看？后面的内容了。
      //这里面的title=${id}是点击详情页时，会把商品的id打包进query传递给后端，后端可以通过this.$route.query.id解开包裹拿到里面的id信息，再通过data方法返回商品相关信息给前端。
    //   this.$router.push("/productDetail/?title=${pid}"");

      ///productDetail/${pid}末尾的pid是一个自定义的动态路由名，本质是一个变量，这个变量是用来装数据的，装好之后会被放到$route.params里面
      this.$router.push(`/productDetail/${pid}.html`);

      //对象形式
      //根据path跳转
      // hits.$router.push({path:`/productDetail/${pid}.html`}

      // 命名的路由(根据router的index.js中定义的name属性。。。
      // this.$router.push({
      //   name:"xiangqiang",
      //   params:{
      //     userId:"123",
      //     zidingyiID:pid
      //   }
      // })
    },
  },
  created(){
      //页面对象创建完成后，建议可以在此时调用接口
    //   2.利用axios对象的get方法。调用后台服务器接口
    //promise写法==>  .then   成功时候的回调
    //下面这个接口是老师给的数据库接口
    // axios.get("http://leeyiqing.site/product.php")
    // .then(res =>{
    //     console.log(res.data);
    //     //从数据库传来的数据就会把上面的list数据覆盖了
    //     this.list = res.data
    // })
  }
};

//单行文本省略
//   white-space: nowrap;
//   overflow: hidden;
//   text-overflow: ellipsis;
</script>


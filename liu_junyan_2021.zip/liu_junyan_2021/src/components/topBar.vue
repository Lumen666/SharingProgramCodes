<template>
  <div id="top-bar">
    <div class="top flex">
      <div class="back" @click="goBack">
        <van-icon name="arrow-left" />
      </div>
      <!-- 在组件内部某个位置添加插槽标签slot,比如topBar这个标签夹的内容就会被显示在slot的位置 -->
      <div class="detail flex-item"><slot></slot></div>
      <div class="menu"><van-icon v-if="isShow" name="more-o" /></div>
    </div>
  </div>
</template>

<style lang="less">
#top-bar {
  width: 100%;
  height: 44px;
  line-height: 44px;
  text-align: center;
  background: white;
  z-index: 999;

  .top {
    .back {
      font-size: 20px;
      margin-left: 10px;
      vertical-align: middle;   
    }
    .menu {
        font-size: 25px;
        margin-right: 10px;
        vertical-align: middle;
      }
    .detail {
      // margin-top: 15px;
      border-bottom: 1px solid #ECECEC;
      vertical-align: middle;
      font-size:20px;
    }
  }
}
</style>


<script>
export default {
  props:{
    isShow:{
      type:Boolean,
      default:true
    }
  },
  methods: {
    goBack() {
      this.$router.go(-1);
    },
  },
};
</script>

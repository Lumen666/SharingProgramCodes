<template>
   <div id="backTop" v-show='isShow' @click='gotoTop'>
        <img src="@/assets/icons/backtop6.png" alt="">
   </div>
</template>

<style lang='less'>
#backTop{
    position: fixed;
    bottom: 200px;
    right: 20px;
    background: white;
    padding: 5px 5px 0 5px;
    border: 5px solid white;
    border-radius: 50%;
    img{
    width: 16px;
    }
}
</style>

<script>
export default{
    data(){
        return {
            isShow:false
        }
    },
    methods:{
        gotoTop(){
                        document.documentElement.scrollTop = 0;
            document.body.scrollTop = 0;
        }
    },
    created() {
        window.addEventListener("scroll", () => {
            // console.log(123)
            // 为了兼容性，兼容IE和老版本的Chrome浏览器。分别监听documentElement （html元素），body（body元素）
            // 老版本的Chrome浏览器 会默认将页面的滚动条加载到body元素上
            // 而其他一些浏览器的滚动条是加载在 html元素上的
            let scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
            // this对象会随着调用的方法的改变他的指向对象会跟着改变
            // 当前事件的回调函数中的this对象指向了window
            // 所以这边需要将15行的回调函数写成箭头函数
            console.log(this)

            this.isShow = false
            if (scrollTop > 200) {
                this.isShow = true
            }
        })
    }
}





</script>

<template>
  <div id="detail" style="background: #f7f7f7">
    <topBar style="position: fixed">
      <ul class="top-item over">
        <li class="left" :class="{ act: actIndex == 0 }" @click="jump(0)">
          <span>商品</span>
        </li>
        <li class="left" :class="{ act: actIndex == 1 }" @click="jump(1)">
          <span>评价</span>
        </li>
        <li class="left" :class="{ act: actIndex == 2 }" @click="jump(2)">
          <span>详情</span>
        </li>
        <li class="left" :class="{ act: actIndex == 3 }" @click="jump(3)">
          <span>推荐</span>
        </li>
      </ul>
    </topBar>
    <div style="height: 44px"></div>
    <!-- 在我们的标签中添加1个ref="xxx"的属性,这样的话可以用this.$refs.xxx操作dom -->
    <div class="proInfo" ref="sp" style="height: 570px; background: white">
      <img src="@/assets/products/iphone13_big.jpg" alt="图片挂了" />
      <div class="phonePirce">¥<span>9799</span>.00</div>
      <h5>
        Apple iPhone 13 Pro Max (A2644) 256GB 银色 支持移动联通电信5G
        双卡双待手机
      </h5>
      <p>
        【限时特惠】3-6号购机享12期免息。PLUS会员专享购机赠1年期AppleCare+服务！选购[快充套装]加9元得20W快充头！更多优惠！
      </p>
    </div>

    <div
      class="pj"
      ref="pj"
      style="height: 400px; background: white; padding: 50px 20px 30px 20px"
    >
      <div class="pj1">
        <div class="up1 over" style="margin: 10px 0">
          <div class="up1_1 left" style="font-size: 16px; font-weight: bolder">
            评价<span style="font-size: 12px; padding-left: 10px">50万+</span>
          </div>
          <div
            class="up1_2 right"
            style="
              font-size: 12px;
              color: #999999;
              vertical-align: sub;
              padding-top: 5px;
            "
          >
            好评度98%
            <img
              src="@/assets/icons/right.png"
              alt=""
              style="width: 12px; vertical-align: sub"
            />
          </div>
        </div>
        <div class="down1 over">
          <span
            class="left"
            style="
              padding: 5px 10px;
              background: #fcedeb;
              display: inline-block;
              height: 18px;
              line-height: 18px;

              border-radius: 20px;
              font-size: 12px;
            "
            >清晰度高(2105)</span
          >
          <span
            class="left"
            style="
              padding: 5px 10px;
              background: #fcedeb;
              display: inline-block;
              height: 18px;
              line-height: 18px;

              border-radius: 20px;
              font-size: 12px;
            "
            >流畅至极(1624)</span
          >
          <span
            class="left"
            style="
              padding: 5px 10px;
              background: #fcedeb;
              display: inline-block;
              height: 18px;
              line-height: 18px;

              border-radius: 20px;
              font-size: 12px;
            "
            >漂亮大方(1222)</span
          >
          <span
            class="left"
            style="
              padding: 5px 10px;
              background: #fcedeb;
              display: inline-block;
              height: 18px;
              line-height: 18px;

              border-radius: 20px;
              font-size: 12px;
            "
            >颜色绚丽(1097)</span
          >
          <span
            class="left"
            style="
              padding: 5px 10px;
              background: #fcedeb;
              display: inline-block;
              height: 18px;
              line-height: 18px;

              border-radius: 20px;
              font-size: 12px;
            "
            >功能强大(1074)</span
          >
          <span
            class="left"
            style="
              padding: 5px 10px;
              background: #fcedeb;
              display: inline-block;
              height: 18px;
              line-height: 18px;

              border-radius: 20px;
              font-size: 12px;
            "
            >手感一流(604)</span
          >
          <span
            class="left"
            style="
              padding: 5px 10px;
              background: #fcedeb;
              display: inline-block;
              height: 18px;
              line-height: 18px;

              border-radius: 20px;
              font-size: 12px;
            "
            >待机给力(408)</span
          >
          <span
            class="left"
            style="
              padding: 5px 10px;
              background: #fcedeb;
              display: inline-block;
              height: 18px;
              line-height: 18px;

              border-radius: 20px;
              font-size: 12px;
            "
            >音质上乘(287)</span
          >
        </div>
      </div>
      <div class="pj2">
        <div class="up2 over" style="margin: 20px 0">
          <div class="up2_1 left">
            <img
              src="@/assets/icons/userhead.png"
              style="width: 20px; vertical-align: sub"
              alt=""
            />
            user55***84
            <img src="@/assets/icons/xing.png" alt="" style="width: 12px" /><img
              src="@/assets/icons/xing.png"
              alt=""
              style="width: 12px"
            /><img
              src="@/assets/icons/xing.png"
              alt=""
              style="width: 12px"
            /><img
              src="@/assets/icons/xing.png"
              alt=""
              style="width: 12px"
            /><img src="@/assets/icons/xing.png" alt="" style="width: 12px" />
          </div>
          <div
            class="up2_2 right"
            style="font-size: 10px; padding-top: 3px; color: #999999"
          >
            2021-11-11
          </div>
        </div>
        <div class="down2">
          <div
            class="down2_1"
            style="
              display: -webkit-box;
              height: 60px;
              overflow: hidden;
              text-align: left;
            "
          >
            iPhone13手机收到了，买的是星光色，超级好看的颜色！外观很漂亮，是我喜欢的颜色，颜值非常高的一款手机。苹果的品质真的是非...
          </div>
          <div>
            <img
              src="@/assets/products/pj1.jpg"
              alt=""
              style="
                width: 60px;
                height: 60px;
                margin: 10px 3px;
                border-radius: 5px;
              "
            />
            <img
              src="@/assets/products/pj2.jpg"
              alt=""
              style="
                width: 60px;
                height: 60px;
                margin: 10px 3px;
                border-radius: 5px;
              "
            />
            <img
              src="@/assets/products/pj3.jpg"
              alt=""
              style="
                width: 60px;
                height: 60px;
                margin: 10px 3px;
                border-radius: 5px;
              "
            />
            <img
              src="@/assets/products/pj4.jpg"
              alt=""
              style="
                width: 60px;
                height: 60px;
                margin: 10px 3px;
                border-radius: 5px;
              "
            />
            <img
              src="@/assets/products/pj4.jpg"
              alt=""
              style="
                width: 60px;
                height: 60px;
                margin: 10px 3px;
                border-radius: 5px;
              "
            />
          </div>
          <div class="seeAll">
            <span
              style="
                padding: 5px;
                border: 1px solid #999999;
                border-radius: 20px;
              "
              >查看全部评价</span
            >
          </div>
        </div>
      </div>
    </div>

    <div
      class="xq"
      ref="xq"
      style="height: 4950px; background: red; overflow: hidden"
    >
      <img src="@/assets/products/xq1.jpg" alt="" style="width: 100%" />
      <img src="@/assets/products/xq2.jpg" alt="" style="width: 100%" />
      <img src="@/assets/products/xq3.jpg" alt="" style="width: 100%" />
      <img src="@/assets/products/xq4.jpg" alt="" style="width: 100%" />
    </div>
    <div class="tj" ref="tj" style="height: 1360px; padding:30px 0;">
      <div style="font-size:26px;font-weight:bolder;margin:20px;font-family:'微软雅黑'; ">热门推荐</div>
      <productList />
    </div>

    <van-goods-action>
      <van-goods-action-icon icon="shop-o" text="店铺" />
      <van-goods-action-icon icon="chat-o" text="客服" dot />
      <!-- 给组件里的购物车图标加一个 to="/cart" 使点击它可以直接跳到购物车页面 -->
      <van-goods-action-icon
        icon="cart-o"
        text="购物车"
        :badge="cartNum"
        to="/cart"
      />
      <van-goods-action-button
        type="warning"
        text="加入购物车"
        color="linear-gradient(135deg,#f2140c,#f2270c 70%,#f24d0c)"
        @click="onAddCart"
      />
      <van-goods-action-button
        type="danger"
        text="立即购买"
        color="linear-gradient(135deg,#ffba0d,#ffc30d 69%,#ffcf0d)"
      />
    </van-goods-action>

    <div class="mask" v-show="show" @click.self="hideMask" @touchmove.prevent>
      <transition name="aaaa">
        <div class="mask-bg" v-show="show">
          <div class="sku-header over">
            <img class="img left" :src="aaa" alt="" />

            <div class="info left">
              <div class="price">
                <span>￥</span>{{ Number(priceNow).toFixed(2) }}
              </div>

              
              <!-- 数据库里的price本来是字符串类型，这里强制转换为数字类型，再强制保留两位小数 -->
              <!-- <div class="choose">已选：{{skuList[0].list[skuList[0].skuIndex]}}  {{skuList[1].list[skuList[1].skuIndex]}}  1件</div> -->
              <div class="choose">
                <span class="chose">已选</span>
                <span
                  style="margin: 0 5px"
                  v-for="(item, index) in skuList"
                  :key="index"
                  >{{ item.list[item.skuIndex] }}</span
                >
                {{ count }}件
              </div>
            </div>
          </div>
          <!-- <div class="sku-body over">
            <dl class="left">
              <dt>颜色</dt>
              <dd class="left" :class="{act: indexColor == index}" @click="indexColor = index " v-for="(item, index) in colorList" :key="index">
                {{ item }}
              </dd>
              
            </dl>

            <dl class="left">
              <dt>尺寸</dt>
              <dd  class="left" :class="{act: indexSize == index}" @click="indexSize = index " v-for="(item, index) in sizeList" :key="index">
                {{ item }}
              </dd>
            </dl>
          </div> -->

          <!-- 循环嵌套的时候，内外层不能重名 -->
          <div class="sku-body">
            <dl class="over" v-for="(item, index) in skuList" :key="index">
              <dt>{{ item.type }}</dt>
              
              <dd
                class="left"
                :class="{ act: j == item.skuIndex }"
                @click="item.skuIndex = j"
               
                v-for="(sku, j) in item.list"
                :key="j"
              >
               <span  @click='changePic(j)'>{{ sku }}</span> 
              </dd>
            </dl>
            <dl class="over">
              <dt class="left qun">数量</dt>
              <van-stepper class="right" v-model="count" @click="confirm" />
            </dl>
          </div>

          <div class="sku-footer">
            <van-button
              @click="addCart"
              round
              type="danger"
              block
              color="linear-gradient(135deg, #f2140c, #f2270c 70%,#f24d0c)"
              >确认</van-button
            >
          </div>
        </div>
      </transition>
    </div>
  </div>
</template>

<script>
//这个页面要应用axios模块，所以在script标签的最上面进行引用
import axios from "axios";
import topBar from "@/components/topBar.vue";
import productList from "@/components/productList.vue";

export default {
  data() {
    //拿到识别信息之后data方法处理之后将返回值返回给前端。拿到的商品数据会将下面的空字符覆盖。
    return {
      // product_title:""
      aaa:require("@/assets/products/a1.jpg"),
      cartNum: 0,
      count: 1,
      product: "",
      actIndex: 0,
      show: false,
      priceNow:8200,
      //mask页面中上面的数据
      aaaList:[
        {price:"9988",img:require("@/assets/products/a1.jpg"),},
        {price:"9988",img:require("@/assets/products/a2.jpg"),},
        {price:"9988",img:require("@/assets/products/a3.jpg"),},
        {price:"9988",img:require("@/assets/products/a4.jpg"),},
        {price:"9988",img:require("@/assets/products/a5.jpg"),},
        ],
      //数组
      colorList: ["星光色", "午夜色", "粉色", "蓝色", "红色"],
      //数组
      sizeList: ["128GB", "256GB", "512GB", "XL", "XXL"],
      //索引变量
      indexColor: 0,
      //索引变量
      indexSize: 0,
      iphoneList:[
        {
          img:require("@/assets/products/a1.jpg"),
        },
                {
          img:require("@/assets/products/a2.jpg"),
        },
                {
          img:require("@/assets/products/a3.jpg"),
        },
                {
          img:require("@/assets/products/a4.jpg"),
        },
                        {
          img:require("@/assets/products/a5.jpg"),
        },
   
      ],
      skuList: [
        {
          type: "颜色",
          list: ["星光色", "午夜色", "粉色", "蓝色", "红色"],
          skuIndex: 0,
        },
        { type: "版本", list: ["128GB", "256GB", "512GB", ], skuIndex: 0 },
      ],
      list: [
        {
          src: require("@/assets/products/iphone13_big.jpg"),
          title:
            "Apple iPhone 13 Pro Max (A2644) 256GB 银色 支持移动联通电信5G 双卡双待手机",
          price: 3099.0,
        },
      ],
    };
  },
  created() {
    document.documentElement.scrollTop = 0;
    //vue全家桶中的router路由器对象---我自己的理解：页面之间的跳转路径，它决定我们点击后去向哪个大类的页面
    console.log(this.$router);

    //route是我们当前项目中，每个页面自己的路由对象
    //----我自己的理解：route是小的商品详情页的跳转路径,要知道商品具体的数据和信息就需要前端向后端传的route包,当我们点击某个商品的时候，这个商品绑定的识别信息会打包发送给后台，通过this.$route.query的方式可以获取这些识别信息
    console.log(this.$route);

    //这个是通过route包里的query属性找到识别信息
    // this.product_title = this.$route.query.id

    //这个是通过route包里的params属性找到识别信息。abc是我们在index.js里自定义的变量名
    // this.product_title = this.$route.params.abc
    //这个是我们后来把动态路由abc改成了pid
    // this.product_title = this.$route.params.pid

    //利用动态路由参数的写法，将列表页的用户点击的商品id获得以后，利用此id调用接口将商品的详细信息查询，将详细信息放入一个变量里方便template标签里进行展示。
    //"http://leeyiqing.site/productByID.php?pid="是后台给的接口，是后台定死的。this.$route.params.pid里的pid是我们自定义的形参，是为了从前台传来的包里取出相关id值
    // axios
    //   .get(
    //     "http://leeyiqing.site/productByID.php?pid=" + this.$route.params.pid
    //   )
    //   .then((res) => {
    //     console.log(res);
    //     this.product = res.data[0];
    //   });

    //通过监听滚动条控制上面商品到推荐四个词的红色样式切换
    window.addEventListener("scroll", this.scrollEvent);
  },
  mounted() {
    console.log("=================我是华丽的分割线=================");
    console.log(this.$route);
  },
  components: {
    topBar,
    productList,
  },
  methods: {
    changePic(j){
      this.aaa = this.aaaList[j].img
      console.log(aaa)
    },
    addCart() {
      this.cartNum++;
      this.show = false;
      //vant里的轻提示Toast是以给方法传参的形式进行调用的
      this.$toast.success({ message: "添加成功", duration: 1000 });
    },
    onAddCart() {
      this.show = true;
    },
    onAddCart() {
      this.show = true;
    },
    hideMask() {
      this.show = false;
    },
    jump(i) {
      this.actIndex = i;
      //   document.documentElement.scrollTop = 1500 +44
      // console.log(document.querySelector(".sp").offsetHeight) 这是原生获得高度写法
      //在我们的js代码中，使用this.$refs可以找到在html中设置的对应的元素
      // console.log(this.$refs.sp.offsetHeight) 这是vue获得高度写法

      let offsetTop = 0;
      if (i == 0) {
        offsetTop = this.$refs.sp.offsetTop;
      } else if (i == 1) {
        offsetTop = this.$refs.pj.offsetTop;
      } else if (i == 2) {
        offsetTop = this.$refs.xq.offsetTop;
      } else if (i == 3) {
        offsetTop = this.$refs.tj.offsetTop;
      }
      document.documentElement.scrollTop = offsetTop;
    },
    scrollEvent() {
      console.log(document.documentElement.scrollTop);
      let scrollTop = document.documentElement.scrollTop;
      if (scrollTop > this.$refs.tj.offsetTop - 44) {
        console.log("推荐");
        this.actIndex = 3;
      } else if (scrollTop > this.$refs.xq.offsetTop - 44) {
        console.log("详情");
        this.actIndex = 2;
      } else if (scrollTop > this.$refs.pj.offsetTop - 44) {
        console.log("评价");
        this.actIndex = 1;
      } else if (scrollTop > this.$refs.sp.offsetTop - 44) {
        console.log("商品");
        this.actIndex = 0;
      }
    },
  },
  destroyed() {
    console.log("移除监听滚条");
    window.removeEventListener("scroll", this.scrollEvent);
  },
};
</script>

<style lang="less">
//元素进入到页面中的过渡及动画
//开始进入页面  .name-enter
.aaaa-enter {
  transform: translateY(100%);
}

//完成进入后的状态    .name-enter-to
.aaaa-enter-to {
  transform: translateY(0);
}

//进入时的动画效果，时间等  .name-enter-active
.aaaa-enter-active {
  transition: all 0.5s linear;
}

//下面3条时离开时的
.aaaa-leave {
  transform: translateY(0);
}

.aaaa-leave-to {
  transform: translateY(100%);
}

.aaaa-leave-active {
  //虽然这里设置的是3s，但是因为关闭这个弹窗的时候mask这个父元素已经被关闭(true => false)了，所以里面的子元素(白色部分)会跟着直接消失，所以这里设置的时间已经无效了。
  transition: all 3s linear;
}



#detail {
  .down1 .left {
    margin: 5px 9px 5px 0;
  }
  .proInfo {
    text-align: left;
    color: #f2270c;
    font-size: 16px;
    margin-bottom: 10px;
    border-radius: 0 0 20px 20px;

    .phonePirce {
      padding: 0 15px;
    }
    span {
      font-size: 30px;
    }
    h5 {
      color: black;
      font-size: 16px;
      text-align: left;
      padding: 0 15px;
    }
    p {
      color: black;
      font-size: 12px;
      text-align: left;
      padding: 10px 15px;
    }
    img {
      width: 100%;
    }
  }

  .pj,
  .xq,
  .tj {
    border-radius: 20px;
    margin: 15px 0;
  }

  .top-item {
    width: 60%;
    margin: 0 auto;
    li {
      width: 25%;

      &.act {
        font-weight: bold;
        color: red;
        span::after {
          content: "";
          display: block;
          height: 3px;
          width: 36px;
          background: linear-gradient(90deg, #f5503a, #fad1cb);
          position: relative;
          bottom: -10px;
          left: -38px;
        }
      }
    }
  }

  .mask {
    width: 100%;
    height: 100vh;
    background: rgba(0, 0, 0, 0.6);
    position: fixed;
    top: 0;
    left: 0;

    .mask-bg {
      width: 100%;
      min-height: 400px;
      max-height: 555px;
      background: white;
      position: absolute;
      bottom: 0;

      .sku-header {
        margin: 20px;
        position: relative;

        .img {
          width: 100px;
          height: 100px;
        }
        .info {
          white-space: nowrap;
          margin-top: 35px;
          .price {
            color: red;
            font-size: 24px;
            font-weight: bold;
            font-family: "微软雅黑";
            span {
              font-size: 14px;
            }
          }
          .choose {
            .chose {
              color: #8c8c8c;
              font-size: 14px;
              padding-left: 10px;
            }
          }
        }
      }
    }

    .sku-body {
      margin: 0 20px;
      dl {
        margin: 10px 0;
        dt {
          text-align: left;
          font-size: 14px;
          font-weight: bold;
          font-family: "黑体";
          padding-left: 10px;
        }
        dd {
          height: 30px;
          line-height: 30px;
          background: #f2f2f2;
          margin: 10px;
          padding: 0 15px;
          border-radius: 15px;
          font-size: 12px;
          border: 1px solid #f2f2f2;
        }

      }

      .qun {
        line-height: 30px;
      }

      
    }
    .sku-footer {
      // border: 1px solid red;
      width: 90%;
      margin: 20px auto;
    }
  }
}
</style>
<template>
  <div id="countDown">
    <span @click="startCount" value="true">点我倒计时:</span>{{ time }}s
  </div>
</template>

<script>
export default {
  data() {
    return {
      time: 3,
      hh: 0,
      mm: 0,
      ss: 0,
      list: [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22],
    };
  },
  methods: {
    //点击触发此函数
    startCount() {
      //    if(this.value )
      //计时规则放入timer变量
      let timer = setInterval(() => {
        //   每秒执行一次--
        this.time--;
        // 执行后若time=0时清除本计时器
        if (this.time == 0) {
          clearInterval(timer);
        }
      }, 1000);
    },
  },
  // created() {
  // setInterval(() => {
  //   let startTime = new Date();
  //   let endTime = new Date("2021-12-2 19:00:00");
  //   // 剩余时间(相减后从毫秒转为秒)
  //   let temp = (endTime - startTime) / 1000;

  //   //小时
  //   this.hh = Math.floor(temp / 3600);
  //   this.hh = this.hh < 10 ? "0" + this.hh : this.hh;

  //   //分
  //   this.mm = Math.floor((temp / 60) % 60);
  //   this.mm = this.mm < 10 ? "0" + this.mm : this.mm;

  //   //秒
  //   this.ss = (temp % 60).toFixed(0);
  //   this.ss = this.ss < 10 ? "0" + this.ss : this.ss;

  //   console.log(this.hh + ":" + this.mm + ":" + this.ss);
  // }, 1000);
  // },

  created() {
    let startTime = new Date();
    let nowHH = startTime.getHours();
    let endTime = new Date();
    // this.list.forEach(item =>{
    //   console.log(item)
    //   console.log(nowHH)
    //   if(item > nowHH){
    //     endTime.setHours(item)
    //     endTime.setMinutes(0)
    //     endTime.setSeconds(0)
    //     console.log(endTime)
    //     return false
    //   }
    // })

    for (let i = 0; i < this.list.length; i++) {
      if (this.list[i] > nowHH) {
        endTime.setHours(this.list[i]);
        endTime.setMinutes(0);
        endTime.setSeconds(0);
        // console.log(endTime);
        // return  立即停止代码，后面的内容不再执行
        // continue 跳过当次循环执行之后的循环
        // break 跳出当此整个代码块（跳出整个循环）并继续执行之后的代码
        break;
      }
    }
  },
};
</script>
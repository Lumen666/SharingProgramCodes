<template>
<!-- （传出）点击发生时，触发getNum函数，导致count++,然后通过自定义事件input被传导至父级mine.vue,父级中的Input事件把值给到绑定的getCountNum函数，这个值被赋予acb，最后在{{abc}}中显示过来 -->
  <div class="dianwo" @click="getNum">计数:{{ count }}</div>
</template>

<script>
export default {
  props: {
    value: {
      type: Number,
      default: 0,
    },
  },
  data() {
    return {
      count: 0,
    };
  },

      //（传入）初次渲染时，因为count.vue被mine.vue调用，在mine.vue中value的值时变量abc给的，此时abc=10，所以这个10被传到count.vue中并赋予count,最后被显示出来。
  created() {
    this.count = this.value;
  },
  methods: {
    getNum() {
      this.count++;
      this.$emit("input", this.count);
    },
  },
};
</script>


<style>
.dianwo{
    border:2px solid red;
    width: 80px;
    display: inline-block;
}
</style>
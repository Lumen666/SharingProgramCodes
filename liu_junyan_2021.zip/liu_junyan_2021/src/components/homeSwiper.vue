

<template>
  <div id="home-swiper">
    <div class="swiper-container">
      <div class="swiper-wrapper">
          <!-- 用列表渲染的方式将图片渲染出来 -->
        <div class="swiper-slide" v-for="(item,index) in imgList" :key="index" ><img :src="item" alt="" /></div>
      </div>
      <!-- 如果需要分页器 -->
      <div class="swiper-pagination"></div>



    </div>
  </div>
</template>

<style lang="less">
#home-swiper{
    width: 100%;
    .swiper-container{
        width: 100%;
        .swiper-pagination-bullet-active{
            background: #FA2C19;
        }
        img{
            width: 100%;
        }
    }

}

</style>

<script>

//swiper的样式、Js全部在它自己的页面进行引用!!!
//引用swiper的css文件不用from，可以通过路径直接引入
import "swiper/dist/css/swiper.min.css";
//引用swiper的js代码直接填node_module里面的文件夹名
import swiper from "swiper";

export default {
    data(){
        //imgList必须以一个返回值的形式给到上面的列表渲染
        return {
            //如果本地图片资源需要通过变量的形式来使用，必须使用require(本地图片地址)的方式加载图片
            imgList:[require('@/assets/banner1.jpg'),require('@/assets/banner2.jpg'),require('@/assets/banner3.jpg'),require('@/assets/banner4.jpg'),require('@/assets/banner5.jpg'),require('@/assets/banner6.jpg')]
        }
    },


  created() {},

//js一定要放在生命周期函数的mounted里面，等页面初次渲染完成之后再加载js
  mounted() {
    var mySwiper = new swiper(".swiper-container", {

      loop: true, // 循环模式选项
      autoplay:true,
      delay:3000,
  

      // 如果需要分页器
      pagination: {
        el: ".swiper-pagination",
        clickable:true
      },

      // 如果需要前进后退按钮
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      }

      
    });
  },
};
</script>
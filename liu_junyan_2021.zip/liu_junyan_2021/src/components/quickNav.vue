<template>
  <div id="quick-nav">
    <div class="swiper-container">
      <div class="swiper-wrapper">
        <!-- 用列表渲染的方式将图片渲染出来 -->
        <div class="swiper-slide" v-for="(item, index) in 2" :key="index">

            <!-- 把写好的ul列表放进了swiper里面 -->
          <ul>
            <li v-for="(item, index) in iconList" :key="index">
              <img :src="item.icons" alt="" />
              <div>{{ item.title }}</div>
            </li>
          </ul>

        </div>
      </div>
      <!-- 如果需要分页器 -->
      <div class="swiper-pagination quick-pagination"></div>
    </div>
  </div>
</template>

<style lang="less">
#quick-nav {
  ul {
    width: 100%;
    li {
      width: 20%;
      float: left;
      margin: 10px 0;
      img {
        width: 42px;
        height: 42px;
        margin: 5px 0;
      }
    }
  }
}
.swiper-pagination-bullet-active{
     background: #FA2C19;
     
}
</style>







<script>
import "swiper/dist/css/swiper.min.css";
import swiper from "swiper";

export default {
  data() {
    return {
      iconList: [
        { icons: require("@/assets/icons/i1.jpg"), title: "京东超市" },
        { icons: require("@/assets/icons/i2.jpg"), title: "数码电器" },
        { icons: require("@/assets/icons/i3.jpg"), title: "京东服饰" },
        { icons: require("@/assets/icons/i4.jpg"), title: "京东生鲜" },
        { icons: require("@/assets/icons/i5.jpg"), title: "京东到家" },
        { icons: require("@/assets/icons/i6.jpg"), title: "充值缴费" },
        { icons: require("@/assets/icons/i7.jpg"), title: "物流查询" },
        { icons: require("@/assets/icons/i8.jpg"), title: "领券" },
        { icons: require("@/assets/icons/i9.jpg"), title: "领金贴" },
        { icons: require("@/assets/icons/i10.jpg"), title: "PLUS会员" },
      ],
    };
  },
  mounted() {
    var mySwiper = new swiper(".quick-container", {

      // 如果需要分页器
      pagination: {
        el: ".quick-pagination"
      }
    });
  },
};
</script>

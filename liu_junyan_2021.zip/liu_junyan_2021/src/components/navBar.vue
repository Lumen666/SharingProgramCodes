<template>
  <!-- 第1步：刷新默认显示首页，首页两字为红色。当点击时触发changepage函数并传值，methods内定义的方法使传进去的值赋予actIndex变量，此时变量的值与1，2，3，4作比较，相等为true的那一项的act被显示。 -->
  <div id="nav-bar">
    <ul>
      <!-- <li class="left" :class="{ act: actIndex == 1 }" @click="changePage(1)"><router-link to="/index">首页</router-link>
        
      </li>
      <li class="left" :class="{ act: actIndex == 2 }" @click="changePage(2)"><router-link to="/sort">分类</router-link>
        
      </li>
      <li class="left" :class="{ act: actIndex == 3 }" @click="changePage(3)"><router-link to="/cart">购物车</router-link>
        
      </li>
      <li class="left" :class="{ act: actIndex == 4 }" @click="changePage(4)"><router-link to="/mine">我的</router-link>
        
      </li> -->

    <!-- 第2步 用循环优化代码-->
    <!-- v-for="item in list" 改成 v-for="(item,index) in list" 并且加上 :key="index" 之后就不会报错 没绑定key的话就不能把item绑定在原来的位置上，新加数据的话就会把现在的挤歪-->
      <!-- <li class="left" :class="{ act: actIndex == item.url }" @click="changePage" v-for="(item,index) in list" :key="index"><router-link :to="item.url">{{item.title}}</router-link> -->
      <li class="left" :class="{ act: actIndex == item.url }"  v-for="(item,index) in list" :key="index"><router-link :to="item.url"><img :src="actIndex == item.url ? item.act : item.def" alt=""></router-link>
      </li>
    </ul>
  </div>
</template>






<script>
export default {
  data() {
    return {
      // list: [{title:"首页",url:"/first"}, {title:"分类",url:"/Category"},{title:"购物车",url:"/cart"},{ title:"我的",url:"/mine"}],
      actIndex: "",
      list:[
        {def:require('@/assets/icons/home.png'),act:require('@/assets/icons/home_act.png'),url:'/first'},
        {def:require('@/assets/icons/category.png'),act:require('@/assets/icons/category_act.png'),url:'/Category'},
        {def:require('@/assets/icons/cart.png'),act:require('@/assets/icons/cart_act.png'),url:'/cart'},
        {def:require('@/assets/icons/mine.png'),act:require('@/assets/icons/mine_act.png'),url:'/mine'}
        ]
    };
  },
  methods: {
    // changePage(e) {
    //   console.log(e);
    //   this.actIndex = e;
    // },
  },
  created(){
    console.log(this.$route)

  //每次创建VUE对象的时候就把获取到的path值（URL）赋予actIndex
    this.actIndex = this.$route.path
  }
};
</script>




<!--如果样式中要使用less预编译css语法，在style后添加lang="less"-->
<style lang="less">
* {
  margin: 0;
  padding: 0;
  list-style: none;
}

.left {
  float: left;
}

.right {
  float: right;
}

#app {
  font-family: "微软雅黑";
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  z-index: 99;

}

//采用了less的嵌套写法，子代放入父代就可以
#nav-bar {
  width: 100%;
  height: 50px;
  line-height: 50px;
  position: fixed;
  bottom: 0px;
  background: #FFFF;


  ul{
  
  li {
    width: 25%;
    text-align: center;
  border-top:1px solid #999;

    a{
        text-decoration: none;
        color:#333;
        img{
          width: 65px;
          height: 50px;
        }
    }
    &.act {
      a{
      color: red;

      }
    }
  }

  // li和act是平级关系。可以写在外面，也可以用嵌套的写法加上&写在li里面
  //   .act{
  //       color:red
  //   }
  }
}




</style>
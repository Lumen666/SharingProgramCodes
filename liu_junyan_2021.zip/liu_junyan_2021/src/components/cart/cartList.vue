<template>
  <div id="cartList">
    <!-- van-card商品卡片组件 -->
    <div class="card-item" v-for="(item, index) in list" :key="index">
        <!-- label-disabled="false"禁用点击复选框内容同时打勾 -->
      <van-checkbox @change="onChangeSelected" v-model="item.checked" checked-color="#F2270C" :label-disabled="true"
        >京东自营</van-checkbox
      >
      <van-card
        :num="item.num"
        :price="Number(item.price).toFixed(2)"
        :title="item.title"
        :thumb="item.img"
        :origin-price="item.op"
      >
        <!-- 在van-card里定义了很多具名插槽。我们在这下面使用到的是一个内置的name叫num的插槽，通过引用template组件，并添加v-slot指令修改num部分的插槽内容 -->
        <template v-slot:num>
          <!-- 这是一个步进器组件 -->
          <van-stepper v-model="item.num" />
        </template>
      </van-card>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    list: {
        type:Array,
        default:[]
    },
  },
  data() {
    return {
        checked:false
    };
  },
  methods:{
      onChangeSelected(){
          let num = 0;
          this.list.forEach(item =>{
              //如果某样商品前面打勾了，则数字+1
              if(item.checked){
                  num++;
              }
          })
            console.log(num)
          //如果num和列表的长度相同则表示全选了
          if(this.list.length == num){
              console.log('全选了')
              this.$emit('allSelected',true)
          }else{
              this.$emit('allSelected',false)
          }
      }
  }
};
</script>

<style lang="less">
#cartList {
  .card-item {
    margin-top: 10px;
    padding: 0 5px;
    background: white;

    border-radius: 10px 10px 10px 10px;
  }
  .van-card__price {
    color: red;
    // font-s
  }
  .van-card {
    background: white;
    padding-bottom: 30px;
  }
  .van-checkbox__icon {
    font-size: 18px;
    color: #929292;
  }
  .van-checkbox {
    padding-top: 30px;

    //   border: 1px solid red;
  }
}
</style>

                
            
<template>
    <van-submit-bar :price="totalPrice" button-text="提交订单" @submit="onSubmit">
      <van-checkbox v-model="gggg" checked-color="#F2270C" @click="onSubmit">全选</van-checkbox>
    </van-submit-bar>
</template>

<script>
export default{
    props:{
        //props关键字定义组件的属性字段，是调用接口的时候给别人使用的，目的使接受别人传递过来的数据。
        //定义的props有两种格式，1.数组形式  2.对象形式
       
        totalPrice:{
            type:Number,
            default:0
        },
        allCheck:{
            type:Boolean,
            default:false
        }
    },
    data(){
        return{
            gggg:false
        }
    },
    methods:{
        onSubmit(){
            console.log("我是提交按钮")
            //子组件向父组件传值的时候，需要自定义1个事件才能通知父元素
            //自定义事件$emit("自定义事件名"，要传的值)
            this.$emit('changeChecked',this.gggg);
        },
        
    },

    //watch是个变化的监听器，这里它监听的checked的值发生变化的时候，就会执行里面的代码。当然，里面的代码也可以用一个点击事件来触发。
    watch:{
        //     checked(){
        //     //自定义事件$emit("自定义事件名"，要传的值)。 代码执行时，会把this.checked传递给父级cart.vue
        //         this.$emit("changeChecked",this.checked)
                
        //     }
        ffff(newVal){
            console.log(newVal)
            this.gggg = newVal
        }
        }

}

//props,data,computed这3个都是Vue对象中定义变量的地方。所以命名不能重复，否则就会提示冲突
//data是本文件中内部的变量，可以任意调用和修改
//computed是根据其它数据通过运行和计算而得出的结果
//props原则上是定义默认值之后，数据由父级元素传值过来并覆盖。注意：不建议直接修改props的值，因为它在原则上是只读的，需要通过父级传值修改。
</script>

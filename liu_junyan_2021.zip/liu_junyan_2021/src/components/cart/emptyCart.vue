<template>
  <div id="empty">
    <div class="cartImg1">
      <img src="@/assets/cartimg1.png" alt="" />
      <p>登录后可同步购物车中商品</p>
    </div>
  </div>
</template>

<style lang="less">
.cartImg1 {
    img {
      width: 90px;
      height: 90px;
      margin: 80px 0 10px 0;
    }
}
</style>
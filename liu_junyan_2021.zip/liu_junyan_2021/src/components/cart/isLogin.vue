<template>
  <div id="login" :class="{isLogin:$store.state.isLogin}">
    <div class="loginHead2" v-if="$store.state.isLogin">
      <span>登录后可同步账户购物车中的商品</span>
      <van-button
        type="primary"
        class="loginBtn"
        size="mini"
        color="linear-gradient(270deg,#f2270c,#ff4b2b)"
        round
        to="/login"
        >登录</van-button
      >
    </div>
  </div>
</template>

<style lang="less">
#login {
  &.isLogin {
    margin-bottom: 60px;
  }
  .loginHead2 {
    background: white;
    height: 60px;
    line-height: 60px;
    border-radius: 0 0 10px 10px;
    .loginBtn {
      font-size: 14px;
      padding: 15px 15px;
      margin-left: 10px;
      //图片、按钮、文字加了这个vertical-align: middle;属性后可以主动和其它元素垂直对齐
      vertical-align: middle;
    }
  }
}
</style>

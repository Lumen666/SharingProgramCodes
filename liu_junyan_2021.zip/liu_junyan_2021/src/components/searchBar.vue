<template>
  <div id="search-bar" class="flex">
    <div class="menu">
      <i class="fa fa-bars" aria-hidden="true"></i>
    </div>
    <div class="search">
      <img src="@/assets/jingdong.png" alt="" class="logo" />
      <input class="search-input" type="search" placeholder="天线宝宝玩偶" />
      <img src="@/assets/sou.png" alt="" class="sou" />
    </div>
    <div class="login" >
      <span v-if="!$store.state.isLogin" @click="changeLogin">登录</span>
      <!-- <span v-else @click="logOut">我已登录</span> -->
      <img src="@/assets/icons/i10.jpg" alt="" v-else @click="logOut">
      </div>
  </div>
</template>

<script>
export default {
  methods:{
    changeLogin(){
      this.$router.push("/login")
    },

    logOut(){
      //退出的时候，把localStorage里的login（key名）的值改为空，刷新页面时读取到的值为空也就默认为未登录状态了
      localStorage.setItem("login",'')
      this.$store.commit('changeLogin')
    }
  }
}
</script>


<style lang = "less">
/* 采用less语法就可以写成嵌套样式 */
#search-bar {
  width: 100%;
  height: 44px;
  text-align: center;
  line-height: 44px;
  background-color: #c82519;
  font-size: 14px;
  position: fixed;
  z-index: 999;

  .menu,
  .login {
    width: 50px;
    background-color: #c82519;
    color: white;
    font-size: 14px;
    /* letter-spacing:4px; */
    img{
      width: 40px;
    }
  }

  .menu {
    font-size: 24px;
    i {
      background-color: #c82519;
      color: white;
    }
  }
  .search {
    /* 自动 */
    flex: 1;
    /* width: 100%; */
    background: white;
    line-height: 30px;
    height: 30px;
    /* 圆角是高度一半的话，就能形成长条椭圆形 */
    border-radius: 15px;
    margin-top: 7px;
    position: relative;

    .logo {
      width: 24px;
      height: 24px;
      position: absolute;
      top: 4px;
      left: 20px;
      border-right: 1px solid #dddddd;
      padding-right: 6px;
      /* margin-right:5px; */
    }

    .sou {
      width: 24px;
      height: 24px;
      position: absolute;
      top: 4px;
      left: 54px;
    }

    .search-input {
      border: none;
      outline: none;
      width: 100%;
      height: 30px;
      border-radius: 15px;
      /* background: #999; */
      text-indent: 80px;
      /* border: 2px solid blue; */
    }
  }
}
</style>





<!-- -->
<template>
  <div id="app">
    <!-- <div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link> -->
      <!-- <h1>{{content}}</h1> -->

      <!-- 3.在template中使用注册好的自定义标签
      
    </div> -->
      <!-- <abc /> -->

    <router-view/>
  </div>
</template>

<script>
//1.引用组件文件
import aaa from "./components/navBar.vue"

export default{

  //引用项目中的组件(其他vue文件)


  // data配置项必须是方法的返回值
  data:  function(){
    return {
      content:"哇哈哈哈哈"
    }
  },
  //2.注册需要使用的自定义组件
  components:{
    abc:aaa
    
  }
}
</script>







<style lang="less">
.flex{
    display: flex;
}
.flex-item{
    flex: 1;
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

h1{
  color: red;
}

#nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}

.left {
  float: left;
}

.right {
  float: right;
}

.over {
  overflow: hidden;
  zoom: 1;
}

//利用伪元素清除浮动,将clear作为类名给某个元素就能帮它清除浮动了
.clear::after{
  content: '';
  display: block;
  clear:both;
}



</style>

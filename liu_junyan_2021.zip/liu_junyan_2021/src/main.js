import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import "@/assets/icons/css/font-awesome.css"
//导入vant组件库
import Vant from 'vant'
//引用vant模块的css文件
import 'vant/lib/index.css'

//引用animate.css动画样式  安装命令npm install animate.css --save
import 'animate.css'


Vue.config.productionTip = false

//将vant模块添加到vue对象中
Vue.use(Vant)

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')

<template>
  <div id="login">
      <topBar :isShow="false">京东登录</topBar>
    <van-form @submit="onSubmit">
      <van-field
        v-model="username"
        name="用户名"
        label="用户名"
        placeholder="用户名"
        :rules="[{ required: true, message: '请填写用户名' }]"
      />
      <van-field
        v-model="password"
        type="password"
        name="密码"
        label="密码"
        placeholder="密码"
        :rules="[{ required: true, message: '请填写密码' }]"
      />
      <div style="margin: 16px">
        <van-button round block type="info" native-type="submit"
          >登录</van-button
        >
      </div>
    </van-form>
  </div>
</template>
<script>
import topBar from '@/components/topBar'


export default {
  data() {
    return {
      username: "",
      password: "",
     
    };
  },
  methods: {
    onSubmit(values) {
        //打印了一下填的内容
      console.log("submit", values);
      //storage 使用setItem方法设置一个本地存储的数据
      //第一个参数，需要存储数据的key(名称)。第二个参数，值。   localStorage数据在本地永久有效，直到手动清除
      localStorage.setItem('login',true)
      //利用Vuex的store对象，提交对应的mutation,来修改vuex中的状态
      this.$store.commit("changeLogin");
      //跳转到首页
      this.$router.push("/first")
    },
  },
  components:{
      topBar
  }
};
</script>

<style lang="less">
#login {
  .van-button {
    background: linear-gradient(90deg, #fab3b3, #ffbcb3 73%, #ffcaba);
    border: none;
    width: 364px;
    height: 50px;
    font-size: 16px;
  }
}
</style>
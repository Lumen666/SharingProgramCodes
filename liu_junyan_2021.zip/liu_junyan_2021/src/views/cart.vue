<template>
  <div id="app" class="about">
    <topBar>购物车</topBar>

    <navBar />
    <login />
    <empty v-if="cartLists.length == 0" />

    <div v-else>
      <!-- 在子组件props内定义的list属性，它的值是一个变量，这个变量是计算的来的总价，这个变量名也就是下面computed定义的方法名 -->
      <cartList :list="cartLists" @allSelected="getAllCheck" />
      <!-- :totalPrice=""  父元素向子元素传值，覆盖子元素内props定义的某种类型的变量的值 -->
    </div>

    <div class="mat"></div>

    <!-- vant的SubmitBar组件里为了规避js语言里数值的bug,传价格的单位是“分”,所以乘以100 -->
    <submitBar
      :allCheck="allChecked"
      :totalPrice="totalPrice * 100"
      @changeChecked="allSelected"
     
    />
  </div>
</template>

<script>
import navBar from "@/components/navBar.vue";
import topBar from "@/components/topBar.vue";
import login from "@/components/cart/isLogin.vue";
import empty from "@/components/cart/emptyCart.vue";
import cartList from "@/components/cart/cartList.vue";
import submitBar from "@/components/cart/submitBar.vue";

export default {
  methods: {
    allSelected(e) {
      console.log("自定义事件触发成功");
      //父级cart.vue收到submitBar传递来的this.checked就会
      this.cartLists.forEach((item, index) => {
        item.checked = e;
      });
    },
    getAllCheck(e){
      console.log(e)
      this.allChecked = e;
    }
  },
  components: {
    navBar,
    topBar,
    login,
    empty,
    cartList,
    submitBar,
  },
  //计算变量computed
  computed: {
    totalPrice() {
      let sum = 0;
      //将购物车内的商品数据遍历
      this.cartLists.forEach((item, i) => {
        //判断，有勾选才计算价格
        if (item.checked) {
          console.log(item.price);
          //这是计算总价的方法
          sum += Number(item.price) * item.num;
        }
      });
      return sum;
    },
  },
  data() {
    return {
      allChecked:false,
      cartLists: [
        {
          img: require("@/assets/cartImg/1.png"),
          title:
            "【2021新款】蓝牙耳机适用于华为手机真无线半入耳式降噪超长续航荣耀苹果小米oppo VENIDER 白色|尊享升级版【智能降噪/触控+长续航】自动配对",
          price: 89,
          num: 1,
          op: 200,
          checked: false,
        },
        {
          img: require("@/assets/cartImg/2.jpg"),
          title: "华为（HUAWEI）HUAWEI P50 Pro智能视窗保护套 大象灰",
          price: 229,
          num: 1,
          op: 388,
          checked: false,
        },
        {
          img: require("@/assets/cartImg/3.jpg"),
          title:
            "冬天穿的网红超火老爹鞋女ins潮2021春季新款百搭运动鞋鞋跑步鞋 白色 35",
          price: 42.48,
          num: 1,
          op: 88,
          checked: false,
        },
        {
          img: require("@/assets/cartImg/4.jpg"),
          title:
            "HUAWEI P50 Pro 4G全网通 原色双影像单元 麒麟9000芯片 万象双环设计 8GB+512GB可可茶金华为手机",
          price: 8789,
          num: 1,
          op: 9899,
          checked: false,
        },
        {
          img: require("@/assets/cartImg/5.jpg"),
          title:
            "华为mate40 pro+5G手机【支持鸿蒙HarmonyOs】 陶瓷黑8G+256G 【原装无线立式充电套装】",
          price: 5859,
          num: 1,
          op: 6800,
          checked: false,
        },
        {
          img: require("@/assets/cartImg/6.jpg"),
          title:
            "华为Mate40 RS保时捷设计 5G手机 麒麟9000芯片【北京可闪送】 陶瓷白【白条12期免息版】 8GB+256GB",
          price: 11589,
          num: 1,
          op: 13585,
          checked: false,
        },
      ],
    };
  },
};
</script>

<style lang="less">
.mat {
  // border: 1px solid red;
  width: 100%;
  height: 60px;
}
</style>
<template>
  <div id="app" class="about">
    <h1>购物车页面</h1>
    <aaa />

  </div>
</template>

<script>
import aaa from "@/components/navBar.vue"

export default {
 
  components: {
    aaa
  }
}

</script>

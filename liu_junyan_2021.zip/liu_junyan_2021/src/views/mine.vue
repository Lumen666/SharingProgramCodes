<template>
  <div id="navBar">
    <div>
      <topBar>我的京东</topBar>
      <!-- 登录状态：{{ $store.state.isLogin }} -->

      <div class="myInfo">
        <div class="up over">
          <div class="touxiang left" @click="logOut">
            <img src="@/assets/icons/userhead.png" alt="" />
            <div class="userName">
              <div class="userName_sub">jd_QbcOOCnHLsh</div>
              <div class="jifen">
                <span>京享值</span><span>8826积分 &gt;</span>
              </div>
            </div>
          </div>

          <div class="settings right">
            <img src="@/assets/icons/setting.png" alt="" />
          </div>
        </div>
        <div class="down">
          <div class="down_item">
            <div>6</div>
            商品收藏
          </div>
          <div class="down_item">
            <div>8</div>
            店铺收藏
          </div>
          <div class="down_item">
            <div>2</div>
            我的足迹
          </div>
        </div>
      </div>
      <div class="bg">
        <div class="bg-sub"></div>
      </div>
      <div class="tools">
        <div class="tool">
          <img class="p1" src="@/assets/icons/wait.png" alt="" /><span
            >待付款</span
          >
        </div>
        <div class="tool">
          <img class="p2" src="@/assets/icons/shouhuo.png" alt="" /><span
            >待收货</span
          >
        </div>
        <div class="tool">
          <img class="p3" src="@/assets/icons/tuihuan.png" alt="" /><span
            >退换/售后</span
          >
        </div>
        <div class="tool">
          <img class="p4" src="@/assets/icons/dingdan.png" alt="" /><span
            >全部订单</span
          >
        </div>
      </div>
      <div class="service">
        <div class="title">工具与服务</div>
        <div class="serve-item over">
          <div class="serve-sub left">
            <img class="serve-img" src="@/assets/icons/s1.png" alt="" />
            <div class="serve-word">客户服务</div>
          </div>
          <div class="serve-sub left">
            <img class="serve-img" src="@/assets/icons/s2.png" alt="" />
            <div class="serve-word">我的预约</div>
          </div>
          <div class="serve-sub left">
            <img class="serve-img" src="@/assets/icons/s3.png" alt="" />
            <div class="serve-word">我的问答</div>
          </div>
          <div class="serve-sub left">
            <img class="serve-img" src="@/assets/icons/s4.png" alt="" />
            <div class="serve-word">闲置换钱</div>
          </div>
          <div class="serve-sub left">
            <img class="serve-img" src="@/assets/icons/s5.png" alt="" />
            <div class="serve-word">高价回收</div>
          </div>
        </div>
      </div>
      <div class="recommond">
        <span class="line" /><span class="squre" /><span class="reWord">为您推荐</span><span class="squre" /><span class="line" />
      </div>
    </div>
    <productList />
    <navBar />
  </div>
</template>
<style lang="less">
#navBar {
  background: #f7f7f7;

  .myInfo {
    background: linear-gradient(60deg, #ff3f5c, #f6281d);
    width: 100%;
    padding-bottom: 20px;
    .up {
      .touxiang {
        width: 300px;
        border: 1px solid red;
        img {
          width: 60px;
          float: left;
          padding: 10px 0 0 10px;
        }
        .userName {
          float: left;
          padding-top: 20px;
          color: white;
          text-align: left;
          .userName_sub{
            margin: 0 0 6px 6px;
          }
          
          .jifen {
            span {
              padding: 2px 6px;
              margin: 10px 5px;
              background: #d61742;
              border-radius: 20px;
            }
          }
        }
      }
      .settings {
        img {
          width: 30px;
          padding: 10px 6px;
        }
      }
    }
    .down {
      display: flex;
      width: 100%;
      flex: 1;
      justify-content: space-around;
      .down_item {
        margin: 20px 0;
        color: white;
        font-size: 12px;
        div {
          font-size: 20px;
          font-family: "微软雅黑";
          margin-bottom: 5px;
        }
      }
    }
  }
  .bg {
    background: linear-gradient(60deg, #ff3f5c, #f6281d);
    .bg-sub {
      background: white;
      width: 100%;
      height: 20px;
      border-radius: 15px 15px 0 0;
    }
  }
  .tools {
    background: white;
    display: flex;
    flex: 1;
    justify-content: space-around;
    padding: 0px 0 20px 0;
    border-radius: 10px;
    // border: 1px solid blue;
    .tool {
      width: 60px;
      font-size: 12px;
      // border: 1px solid red;
      .p1 {
        width: 44px;
      }
      .p2 {
        width: 44px;
      }
      .p3 {
        width: 44px;
      }
      .p4 {
        width: 44px;
      }

      span {
        display: block;
      }
    }
  }
  .service {
    background: white;
    margin: 10px 0;
    border-radius: 10px;
    padding-bottom: 15px;

    .title {
      padding: 20px;
      text-align: left;
      font-family: "微软雅黑";
      font-weight: bolder;
    }
    .serve-item {
      // border:1px solid blue;
      .serve-sub {
        width: 80px;
        margin: 5px;
        // border:1px solid yellow;

        .serve-img {
          width: 40px;
          // border:1px solid red;
        }
        .serve-word {
          font-size: 12px;
          padding-top: 5px;
        }
      }
    }
  }
  .recommond {

    margin-bottom:10px;
    height: 60px;
    line-height: 60px;
    // border: 1px solid red;
    .line {
      display: inline-block;
      background: #999999;
      width: 120px;
      height: 1px;
      transform: translateY(-2px);
    }
    .squre {
      display: inline-block;
      width: 6px;
      height: 6px;
      background-color: #999999;
      transform: rotateZ(45deg) translate(0,0);
      
    }
    .reWord {
      // border: 1px solid red;
      height: 60px;
      width: 80px;
      font-size: 14px;
      color: #999999;
      display: inline-block;
    }
  }
}
</style>

<script>
import navBar from "@/components/navBar.vue";
import topBar from "@/components/topBar.vue";
import productList from '@/components/productList.vue'

export default {
  components: {
    navBar,
    topBar,
    productList
  },
  methods: {
    logOut() {
      //退出的时候，把localStorage里的login（key名）的值改为空，刷新页面时读取到的值为空也就默认为未登录状态了
      localStorage.setItem("login", "");
      this.$store.commit("changeLogin");
      this.$router.push("/login");
    },
  },
  data() {
    return {
      abbb: 0,

    };
  },
  created() {
    // document.cookie = "a  =  1";
    // document.cookie = "b  =  2";
    // document.cookie = "c  =  3";
    // document.cookie = "d  =  4";
    // document.cookie = "e  =  5";
    // document.cookie = "f  =  6";

    // let cookieStr = document.cookie;
    // let cookieArr = cookieStr.split(";");
    // // console.log(cookieArr)

    // cookieArr.forEach((item) => {
    //   let cookieArr2 = item.split("=");

    //   if (cookieArr2[0] == "c") {
    //     this.abbb = cookieArr2[1];
    //   }
    //   console.log(cookieArr2[0]);
    //   console.log(cookieArr2[1]);
    // });

    // let testDate = new Date("2021-12-03 11:10:00");
    // // console.log(testDate.toString())

    // document.cookie = "account = yt123; expires=" +testDate.toString()
    // document.cookie = "account = yt124; expires=" +testDate.toGMTString()

    let date = new Date();
    date.setTime(date.getTime() + 1 * 60 * 1000);
    document.cookie = "wahaha=kakaka;expires=" + date.toGMTString();

    localStorage.setItem(
      "obj",
      JSON.stringify({ username: "ggg1", pwd: "xxd" })
    );
  },
};
</script>


<style lang="less">
#navBar {
  .li-test:nth-of-type(odd) {
    background: #999;
  }
}
</style>


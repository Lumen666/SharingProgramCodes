<template>
<!-- template下面只能有一个根节点（一个大的div) -->
 
 
  <div class="home">
    <searchBar />
    <div style="height:44px;background-color:#c82519"></div>

    <backTop />
    <homeSwiper />
    <quickNav />
    <productList />
    <aaa />
    <!-- 下面垫一块砖-->
    <div style="height:50px;background-color:red"></div>
  </div>

</template>

<style>
body{
  background: #F6F6F6;
}
</style>

<script>
// import Search from '../components/search.vue'
// @ is an alias to /src  =>  @是vue中绝对路径的一个简写，比如下面这句可以写为import search from "@/components/search.vue"

//1.将组件中的搜索框文件引用到本页面
import search from "../components/searchBar.vue"
import bbb from "@/components/homeSwiper.vue"

import ccc from "@/components/quickNav.vue"

import productList from "@/components/productList.vue"

import aaa from "@/components/navBar.vue"

import backTop from "@/components/backtop.vue"




//2.将引用来的组件注册，并自定义组件的名字
export default {
  name: 'Home',
  components: {
    searchBar:search,
    homeSwiper:bbb,
    quickNav:ccc,
    productList,
    aaa,
    backTop


  }
}
</script>

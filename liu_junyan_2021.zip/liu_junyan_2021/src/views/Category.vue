<template>
  <div id="Category" class="Category">
    <topBar :isShow="false" class="topBar">
      <div class="father">
        <input
          class="search"
          type="search"
          placeholder="核桃酥"
          maxlength="20"
        />
        <img src="@/assets/FDJ.png" alt="" />
      </div>
    </topBar>

    <div ref="ff" class="main">
      <div class="aside left">
        <ul
          :class="{ slowUp: slowUp }"
          ref="ul"
          :style="{ transform: 'translateY(' + offsetY + 'px)' }"
          @touchend="onTouchUp"
          @touchmove="onTouchMove"
          @touchstart="onTouchDown"
        >
          <!-- @mousedown="onMouseDown"
        @mousemove="onMouseMove"
        @mouseup="onMouseUp" -->
          <!-- <ul class="aside_ul"> -->
          <li
            class="aside_li"
            v-for="(item, index) in sortList"
            :key="index"
            @click="changeIndex(index)"
          >
            <div :class="{ current: index == nowIndex }">
              {{ item.name }}
            </div>
          </li>
          <!-- </ul> -->
        </ul>
      </div>

      <div
        class="content right"
        style="overflow:auto;"
      >
        <ul
          class="ulPage"
          :class="{ slowUp: slowUp }"
          v-show="nowIndex == 0"
          style="padding-bottom:80px"
        >
          <div class="up over">
            <p>热门分类</p>
            <span
              ><img
                class="rankImg"
                src="@/assets/Category/rank.png"
                alt="" />排行榜<img
                class="rankGoImg"
                src="@/assets/Category/gt.png"
                alt=""
            /></span>
          </div>

          <div class="down over">
           
            <div
              class="goods left"
              v-for="(item, index) in goodsList"
              :key="index"
            >
              <img class="goodsImg" :src="item.img" alt="" />
              <p class="goodsWords">{{ item.words }}</p>
            </div>
          </div>
        </ul>

        <ul
          class="ulPage"
          :class="{ slowUp: slowUp }"
          v-show="nowIndex == 1"
          style="padding-bottom:80px"
          
        >
          <div class="up over">
            <p>热门品牌</p>
          </div>
          <div class="down over">
            <div
              class="goods left"
              v-for="(item, index) in remenList"
              :key="index"
            >
              <img class="goodsImg" :src="item.img" alt="" />
              <p class="goodsWords">{{ item.words }}</p>
            </div>
          </div>

          <div class="up over">
            <p>手机通讯</p>
          </div>
          <div class="down over">
            <div
              class="goods left"
              v-for="(item, index) in tongxunList"
              :key="index"
            >
              <img class="goodsImg" :src="item.img" alt="" />
              <p class="goodsWords">{{ item.words }}</p>
            </div>
          </div>

          <div class="up over">
            <p>运营商</p>
          </div>
          <div class="down over">
            <div
              class="goods left"
              v-for="(item, index) in yunyingList"
              :key="index"
            >
              <img class="goodsImg" :src="item.img" alt="" />
              <p class="goodsWords">{{ item.words }}</p>
            </div>
          </div>

          <div class="up over">
            <p>手机配件</p>
          </div>
          <div class="down over">
            <div
              class="goods left"
              v-for="(item, index) in peijianList"
              :key="index"
            >
              <img class="goodsImg" :src="item.img" alt="" />
              <p class="goodsWords">{{ item.words }}</p>
            </div>
          </div>

          <div class="up over">
            <p>摄影摄像</p>
          </div>
          <div class="down over">
            <div
              class="goods left"
              v-for="(item, index) in sheyingList"
              :key="index"
            >
              <img class="goodsImg" :src="item.img" alt="" />
              <p class="goodsWords">{{ item.words }}</p>
            </div>
          </div>

          <div class="up over">
            <p>影音娱乐</p>
          </div>
          <div class="down over" >
            <div
              class="goods left"
              v-for="(item, index) in yuleList"
              :key="index"
            
            >
              <img class="goodsImg" :src="item.img" alt="" />
              <p class="goodsWords">{{ item.words }}</p>
            </div>
          </div>

          <div class="up over">
            <p>数码配件</p>
          </div>
          <div class="down over">
            <div
              class="goods left"
              v-for="(item, index) in shumaList"
              :key="index"
            >
              <img class="goodsImg" :src="item.img" alt="" />
              <p class="goodsWords">{{ item.words }}</p>
            </div>
          </div>
        </ul>
      </div>
    </div>

    <navBar />
  </div>
</template>
<style lang="less">
#Category {
  .topBar {
    position: fixed;
    .father {
      position: relative;
      img {
        width: 24px;
        height: 24px;
        position: absolute;
        left: 40px;
        top: 12px;
      }
    }
    .search {
      background: #f7f7f7;
      height: 30px;
      border: none;
      border-radius: 16px;
      width: 90%;
      font-size: 12px;
      padding-left: 56px;
    }
  }
  .main {
    padding: 45px 0 0 0;
    width: 100%;
    height: 100vh;
    background: f7f7f7;
    box-sizing: border-box;
    overflow: hidden;

    .aside {
      width: 85px;
      background: pink;
      .slowUp {
        -webkit-transition: all 0.3s linear;
        transition: all 0.3s linear;
      }
      .aside_li {
        width: 85px;
        height: 46px;
        background: #f7f7f7;
        line-height: 46px;
        font-size: 13px;
      }
      .current {
        color: red;
        background: white;
      }
    }
    .content {
      height: 100%;
      //calc(100% - 85px) 减号左右空格必须留！！！！
      width: calc(100% - 85px);
      background-color: white;
      position: relative;
      .ulPage {
        position: absolute;
        top: 0;
        left: 0;
        &.slowUp {
          -webkit-transition: all 0.3s linear;
          transition: all 0.3s linear;
        }
      }
      .up {
        width: 100%;
        padding: 20px 0;
        // border: 1px solid red;
        p {
          float: left;
          font-size: 14px;
          font-family: "微软雅黑";
          font-weight: bolder;
          padding-left: 10px;
        }
        span {
          float: right;
          font-size: 12px;
          vertical-align: middle;
          padding-right: 10px;
          color: #848689;
          .rankImg,
          .rankGoImg {
            width: 12px;
            height: 12px;
            vertical-align: sub;
            padding: 0 3px;
          }
        }
      }

      // .down {
      //   display: flex;
      //   justify-content: space-around;
      //   // flex-wrap: wrap;
      //   width: 100%;
      //       border: 1px solid red;

      //   .goods {
      //     // border: 1px solid blue;
      //     width: 90px;

      //     .goodsImg {
      //       width: 70px;
      //       // border: 1px solid red;
      //     }
      //     .goodsWords {
      //       font-size: 12px;
      //     }
      //   }
      // }

      .down {
        width: 100%;
        // border: 1px solid red;

        .goods {
          // border: 1px solid blue;
          width: 90px;
          padding: 10px 3px;

          .goodsImg {
            width: 70px;
            // border: 1px solid red;
          }
          .goodsWords {
            font-size: 12px;
          }
        }
      }
    }
  }
}
</style>

<script>
import navBar from "@/components/navBar.vue";
import topBar from "@/components/topBar.vue";

export default {
  components: {
    navBar,
    topBar,
  },
  data() {
    return {
      slowUp: false,
      nowIndex: 0,
      start: 0,
      end: 0,
      offsetY: 0,
      tempY: 0,
      sortList: [
        { name: "热门推荐" },
        { name: "手机数码" },
        { name: "京东超市" },
        { name: "家用电器" },
        { name: "电脑办公" },
        { name: "玩具乐器" },
        { name: "家具厨具" },
        { name: "家具家装" },
        { name: "内衣配饰" },
        { name: "男装" },
        { name: "男鞋" },
        { name: "女装" },
        { name: "女鞋" },
        { name: "美妆护肤" },
        { name: "医药保健" },
        { name: "酒水饮料" },
        { name: "运动户外" },
        { name: "汽车生活" },
        { name: "礼品鲜花" },
        { name: "京东国际" },
        { name: "宠物生活" },
        { name: "二手商品" },
        { name: "拍卖" },
        { name: "箱包手袋" },
        { name: "钟表珠宝" },
        { name: "农资绿植" },
        { name: "生活旅行" },
        { name: "奢侈品" },
        { name: "计生情趣" },
        { name: "艺术邮币" },
        { name: "特产馆" },
        { name: "京东金融" },
        { name: "国际名牌" },
        { name: "房产" },
        { name: "工业品" },
      ],
      goodsList: [
        { img: require("@/assets/Category/1.jpg"), words: "空调" },
        { img: require("@/assets/Category/2.jpg"), words: "冰箱" },
        { img: require("@/assets/Category/3.png"), words: "电脑" },
        { img: require("@/assets/Category/4.png"), words: "手机" },
        { img: require("@/assets/Category/5.jpg"), words: "全面屏手机" },
        { img: require("@/assets/Category/7.jpg"), words: "保健品" },
        { img: require("@/assets/Category/8.jpg"), words: "游戏手机" },
        { img: require("@/assets/Category/9.jpg"), words: "口罩" },
        { img: require("@/assets/Category/10.jpg"), words: "驱蚊用品" },
        { img: require("@/assets/Category/11.jpg"), words: "电磁炉" },
        { img: require("@/assets/Category/12.jpg"), words: "电热水壶" },
        { img: require("@/assets/Category/13.jpg"), words: "数据线" },
        { img: require("@/assets/Category/14.jpg"), words: "图书" },
        { img: require("@/assets/Category/15.jpg"), words: "美妆护肤" },
        { img: require("@/assets/Category/16.jpg"), words: "除菌液" },
        { img: require("@/assets/Category/17.jpg"), words: "休闲零食" },
        { img: require("@/assets/Category/18.jpg"), words: "充电宝" },
        { img: require("@/assets/Category/19.jpg"), words: "体温计" },
        { img: require("@/assets/Category/20.jpg"), words: "投影机" },
        { img: require("@/assets/Category/21.jpg"), words: "游戏机" },
      ],
      remenList: [
        //热门品牌
        { img: require("@/assets/Category/shouji/1.png"), words: "小米" },
        { img: require("@/assets/Category/shouji/2.jpg"), words: "华为" },
        { img: require("@/assets/Category/shouji/3.jpg"), words: "荣耀" },
        { img: require("@/assets/Category/shouji/4.jpg"), words: "iPhone" },
        { img: require("@/assets/Category/shouji/5.png"), words: "vivo" },
        { img: require("@/assets/Category/shouji/6.png"), words: "OPPO" },
        { img: require("@/assets/Category/shouji/7.jpg"), words: "魅族" },
        { img: require("@/assets/Category/shouji/8.png"), words: "三星" },
        { img: require("@/assets/Category/shouji/9.jpg"), words: "一加" },
        { img: require("@/assets/Category/shouji/10.jpg"), words: "努比亚" },
      ],
      tongxunList: [
        //手机通讯
        { img: require("@/assets/Category/shouji/12.jpg"), words: "老人机" },
        { img: require("@/assets/Category/shouji/13.jpg"), words: "手机" },
        {
          img: require("@/assets/Category/shouji/14.jpg"),
          words: "全面屏手机",
        },
        { img: require("@/assets/Category/shouji/15.jpg"), words: "游戏手机" },
        { img: require("@/assets/Category/shouji/16.jpg"), words: "拍照手机" },
        { img: require("@/assets/Category/shouji/17.jpg"), words: "对讲机" },
        { img: require("@/assets/Category/shouji/18.jpg"), words: "京东回收" },
        { img: require("@/assets/Category/shouji/19.jpg"), words: "女性手机" },
        { img: require("@/assets/Category/shouji/20.jpg"), words: "京东维修" },
      ],
      yunyingList: [
        //运营商
        { img: require("@/assets/Category/shouji/21.png"), words: "合约机" },
        { img: require("@/assets/Category/shouji/22.png"), words: "选号卡" },
        { img: require("@/assets/Category/shouji/23.jpg"), words: "办套餐" },
        { img: require("@/assets/Category/shouji/24.jpg"), words: "京东网厅" },
      ],
      peijianList: [
        //手机配件
        { img: require("@/assets/Category/shouji/25.jpg"), words: "数据线" },
        {
          img: require("@/assets/Category/shouji/26.jpg"),
          words: "手机存储卡",
        },
        { img: require("@/assets/Category/shouji/27.jpg"), words: "充电宝" },
        { img: require("@/assets/Category/shouji/28.jpg"), words: "手机贴膜" },
        { img: require("@/assets/Category/shouji/29.jpg"), words: "手机耳机" },
        { img: require("@/assets/Category/shouji/30.jpg"), words: "蓝牙耳机" },
        { img: require("@/assets/Category/shouji/31.jpg"), words: "手机支架" },
        { img: require("@/assets/Category/shouji/32.jpg"), words: "手机饰品" },
        { img: require("@/assets/Category/shouji/33.jpg"), words: "车载配件" },
        { img: require("@/assets/Category/shouji/34.jpg"), words: "充电宝" },
        { img: require("@/assets/Category/shouji/35.jpg"), words: "手机电池" },
        { img: require("@/assets/Category/shouji/36.jpg"), words: "创意配件" },
      ],
      sheyingList: [
        //摄影摄像
        { img: require("@/assets/Category/shouji/37.jpg"), words: "单反相机" },
        { img: require("@/assets/Category/shouji/38.jpg"), words: "数码相机" },
        { img: require("@/assets/Category/shouji/39.jpg"), words: "拍立得" },
        { img: require("@/assets/Category/shouji/40.jpg"), words: "户外器材" },
        {
          img: require("@/assets/Category/shouji/41.jpg"),
          words: "单电/微单相机",
        },
        { img: require("@/assets/Category/shouji/42.jpg"), words: "摄像机" },
        { img: require("@/assets/Category/shouji/43.jpg"), words: "运动相机" },
        { img: require("@/assets/Category/shouji/44.jpg"), words: "镜头" },
        { img: require("@/assets/Category/shouji/45.png"), words: "冲印服务" },
      ],
      yuleList: [
        //影音娱乐
        {
          img: require("@/assets/Category/shouji/46.jpg"),
          words: "便携/无线音箱",
        },
        { img: require("@/assets/Category/shouji/47.jpg"), words: "音箱/音响" },
        { img: require("@/assets/Category/shouji/49.jpg"), words: "耳机/耳麦" },
        { img: require("@/assets/Category/shouji/50.jpg"), words: "麦克风" },
        { img: require("@/assets/Category/shouji/51.jpg"), words: "专业音频" },
        { img: require("@/assets/Category/shouji/48.jpg"), words: "MP3/MP4" },

      ],
      shumaList: [
        //数码配件
        { img: require("@/assets/Category/shouji/52.jpg"), words: "存储卡" },
        {
          img: require("@/assets/Category/shouji/53.jpg"),
          words: "三脚架/云台",
        },
        { img: require("@/assets/Category/shouji/54.jpg"), words: "数码支架" },
        { img: require("@/assets/Category/shouji/55.jpg"), words: "读卡器" },
        { img: require("@/assets/Category/shouji/56.jpg"), words: "滤镜" },
        {
          img: require("@/assets/Category/shouji/57.jpg"),
          words: "相机清洁/贴膜",
        },
        { img: require("@/assets/Category/shouji/58.jpg"), words: "相机包" },
        {
          img: require("@/assets/Category/shouji/59.jpg"),
          words: "闪光灯/手柄",
        },
        {
          img: require("@/assets/Category/shouji/60.jpg"),
          words: "电池/充电器",
        },
      ],
    };
  },
  methods: {
    // onMouseDown(e) {
    //   // console.log("onMouseDown");
    //   this.start = e.clientY
    // },
    // onMouseMove(e) {
    //   // console.log("onMouseMove");
    //   if(this.start){
    //      this.end = e.clientY
    //   this.offsetY = this.end - this.start
    //   }

    // },
    // onMouseUp(e) {
    //   // console.log("onMouseUp");
    //   this.start=''
    // },
    changeIndex(e) {
      this.nowIndex = e;
      console.log(this.nowIndex);
      if (this.nowIndex == 0) {
        this.contentMinTop = 0;
      } 
     
    },

    //----------------------------------------------------------------
    onTouchDown(e) {
      this.slowUp = false;
      console.log(this.slowUp);

      // 手指触碰到屏幕时获取Y坐标
      this.start = e.changedTouches[0].clientY;
    },
    onTouchMove(e) {
      if (this.start) {
        this.end = e.changedTouches[0].clientY;
        //this.tempY存的是上一次移动的距离，把this.tempY加入当次移动距离，意味着我们以上次的止步点为起点再次移动
        this.offsetY = this.end - this.start + this.tempY;
        // this.offsetY = this.end - this.start;
        this.offsetY = this.offsetY > 150 ? 150 : this.offsetY;

        //可滑动的高度 = ul元素的高度 - 可视区域的高度
        let limit = -(
          this.$refs["ul"].offsetHeight -
          this.$refs["ff"].offsetHeight +
          94
        );

        if (this.offsetY < limit - 150) {
          this.offsetY = limit - 150;
        }
      }
    },

    onTouchUp(e) {
      this.slowUp = true;
      console.log(this.slowUp);

      // console.log("onMouseUp");
      // this.offsetY < 0 ? this.offsetY:0

      this.start = 0;
      this.offsetY = this.offsetY > 0 ? 0 : this.offsetY;
      let limit = -(
        this.$refs["ul"].offsetHeight -
        this.$refs["ff"].offsetHeight +
        94
      );

      if (this.offsetY < limit) {
        this.offsetY = limit;
      }

      this.tempY = this.offsetY;
    },
    //----------------------------------------------------------------
   
  },
  
};
</script>

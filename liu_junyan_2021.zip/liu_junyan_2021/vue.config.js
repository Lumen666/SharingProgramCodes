//1.Vue网页写好之后，在终端执行 npm run build构建dist文件夹和文件
//2.打开phpStudy，启动阿帕奇服务器
//3.将dist中的内容复制到phpStudy的www文件夹内
//4.如果dist中的内容直接在www中，则之后访问不需要在www.xxx.com后面加分页地址
//5.如果dist中的内容放在www里的abc文件夹里，则访问时需要写www.xxx.com/abc

module.exports = {
    //如果将来我们希望访问我们网站的页面地址（http://www.xxx.com/dist）的话，需要将publicPath修改为"/dist/",也就是说真正的网页内容在/dist中
    //如果不把网页内容放在分页路径中，就不用改，用默认的'/'就好
    publicPath: '/',

    //打包后默认输出的文件夹叫dist,但如果想指定其它名字，可以这样改。
    outputDir:"mingzi"

}